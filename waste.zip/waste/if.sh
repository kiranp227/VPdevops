#!/bin/bash
if [ $1 -gt 0 ]
then 
  echo " $1 is a positive number "
else
  echo " $1 a is negative number "
fi
