#!/bin/bash
for var in {1..8}
do 
echo {1..8}
done

