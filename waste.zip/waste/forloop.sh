for ((a=0; a <= 9 ; a++))
do
 echo "this is $a"
done

