#!/bin/bash
#first script
#clear
echo "hello Devops placement batch"

