#!/bin/bash
echo hello
daet
