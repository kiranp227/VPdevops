#!/bin/bash
#printing email address and name
echo " name: kiran pallapothu "
echo " Email address: kiran.p227@gmail.com "
