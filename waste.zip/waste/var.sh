#!/bin/bash
NAME="kiran pallapothu"
MAIL="kiran.p227@gmail.com"
echo $NAME
echo $MAIL
echo $0
echo $1
echo $2
echo $3
echo $$
echo $*
